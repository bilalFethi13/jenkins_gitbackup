package com.muthu4all.checkstyle;

public class Sample {
	/**
        * This is sample method.
  	*/
	public Boolean shouldBeWarning() {
		return null;
	}
}
